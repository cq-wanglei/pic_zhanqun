<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>視頻在线播放中...請耐心等待</title>
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<meta http-equiv="Cache-Control" content="no-transform" />
<meta http-equiv="Cache-Control" content="no-siteapp"/>
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=0.5, maximum-scale=2.0, user-scalable=yes"/><style type="text/css">
<!--
body {
 background-color: #000033;
}
-->
</style>
</head>
<body>
<div align="center">
</div>

<p align="center">
<a href="/"  title=""><font size="4" color="red">返回首頁 </font></a>&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; <font size="6" color="red"><b>視頻正在加載中 請耐心等待......</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="/play.php"   title="播放下壹個視頻"><font size="4" color="red">播放下壹個視頻</font></a></p>
<p align="center"><iframe vspace="0" hspace="0" scrolling="no" frameborder="0" id="clip" name="clip" width="800" height="550" src="/fang.php" ></iframe></p>
<p align="center">
</p>
<p align="center">
<br>
<font size="1" color="red">本物品內容可能令人反感；不可將本物品內容派發，傳閱，出售，出租，交給<br>
或出借予年齡未滿 18 歲的人士出示，播放或播映。<br>
<br>
This article contains material which may offernd and may not be 
distributed, circulated, sold, hired, given, lent, shown, <br>
played or projected to a person under the age of 18 years. All models are 18 or 
older. </font><br>
</p><br>
<div style='display:none'>
<script src="/tj.js"></script>
</div>

 </body>
</html>
        