<div id="a1"></div>
<script type="text/javascript" src="http://www.ckplayer.com/ckplayer/6.8/ckplayer.js" charset="utf-8"></script><script type="text/javascript">
    var flashvars={
        c:0,
        p:1
    };
    var params={bgcolor:'#FFF',allowFullScreen:true,allowScriptAccess:'always',wmode:'transparent'};
    var video=['http://y.syasn.com/3a/3a<?php echo rand(1,91); ?>.mp4->video/mp4'];
    CKobject.embed('/ckplayer/ckplayer.swf','a1','ckplayer_a1','800','550',true,flashvars,video,params);
</script>