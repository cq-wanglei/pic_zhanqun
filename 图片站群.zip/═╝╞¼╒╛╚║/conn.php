﻿<?php


$tempu=parse_url($_SERVER['SERVER_NAME']);  
$message=$tempu['path']; 

$aa = file_get_contents('conf.ini');
$bb = explode("\r\n", $aa);
for($i = 0 ;$i < count($bb) ;$i++){
	$cc = explode('----', $bb[$i]);
	if ($message == $cc[0] || $message == 'www.'.$cc[0]) {
		$key = iconv("GB2312//IGNORE", "UTF-8", $cc[1]);
	}
}

if (!isset($key)) {
	$key = '青青草在线播放观看';
}
$url = $_SERVER['SERVER_NAME'];




?>