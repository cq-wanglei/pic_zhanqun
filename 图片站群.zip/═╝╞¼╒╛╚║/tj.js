document.write ('<script type="text/javascript"  src="//js.users.51.la/18858351.js"></script>');
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?143ed756733c9c0d0cf1424b5c93052c";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
